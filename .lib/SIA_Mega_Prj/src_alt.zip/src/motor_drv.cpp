/*
 *  Interrupt and PWM utilities for 8 bit Timer3 on ATmega256
 *  
 */

#include <arduino.h>
#include "motor_drv.h"

static motor_t motor[MAX_MOTOR]; 


ISR(TIMER2_OVF_vect)
{
  if(TIMSK2 & (1<<OCIE2B))
  {
    DDRH |= (1<<PH6);
    PORTH |= (1<<PH6);
    OCR2B = motor[MOTOR3].Speed;
  }
}

#if 0
ISR(TIMER2_COMPA_vect)
{
  //DDRB |= (1<<PB4);
  //PORTB &= ~(1<<PB4);
}
#endif
ISR(TIMER2_COMPB_vect)
{  
   DDRH |= (1<<PH6);
   PORTH &= ~(1<<PH6);
}

//Motor 1	D9 \ PH6 ( OC2B )	D15  \ PJ0 ( RXD3/PCINT9 )

void motorDriverGo(	uint8_t motorID, 
					uint8_t mxDir, int8_t mxSpeed,
					uint8_t myDir, int8_t mySpeed,
					uint8_t mzDir, int8_t mzSpeed
				)
{

   if(motorID & MOTOR_ID_3)
   {
       TIMSK2 &= ~(1<<OCIE2B);           			// clears the timer overflow interrupt enable bit 	   
       DDRH |= (1<<PH6);
       PORTH &= ~(1<<PH6);
       DDRJ |= (1<<PJ0);
       PORTJ &= ~(1<<PJ0);
       
       if(mzSpeed == 0)  // motor stop
       {
			TIMSK2 &= ~((1<<OCIE2B) | (1<<TOIE2));
			TIFR0 = (1<<OCIE2B) | (1<<TOIE2);
		  
			PORTH &= ~(1<<PH6);
			PORTJ &= ~(1<<PJ0);        		  
			
			motor[MOTOR3].isActive = false;           //Stop
		//	return;
       }
       else
	   {
			motor[MOTOR3].isActive = true;               //Start
			if(mzDir)
			{
				motor[MOTOR3].Dir =	FORWARD;
				motor[MOTOR3].Speed = 255 - ((int)mzSpeed * 255) / 100;
				PORTJ |= (1<<PJ0);
			}
			else
			{
				motor[MOTOR3].Dir = BACKWARD;
				motor[MOTOR3].Speed = (((int)mzSpeed * 255) / 100);
				PORTJ &= ~(1<<PJ0);
			}
		   
			OCR2B = motor[MOTOR3].Speed;
			TCCR2A = (0 << COM2A0) | (0 << COM2B0) | (0 << WGM21) | (0 << WGM20);
			TCCR2B = (0 << CS22) | (1 << CS21) | (0 << CS20) | (1 << WGM22) ;

			TIMSK2 |= (1<<OCIE2B) | (0<<OCIE2A) | (1<<TOIE2);  
		}	   
   }

   if(motorID & MOTOR_ID_1)
   {  
		//DDRx |= (1<<Px0);
        //PORTx &= ~(1<<Px0);
	    //PORTx |= (1<<Px0);
		
        pinMode(MOTORSHIELD_IN1,OUTPUT);
        pinMode(MOTORSHIELD_IN2,OUTPUT);

		DDRH |= (1 << 3);               	// OC4A pin as outputs 
        PORTH &= ~(1 << 3);               	// Clear the Pin 

		if(mxSpeed == 0)  // motor stop
		{
			PORTH &= ~(1 << 3);               // // Clear the Pin 

			TCCR4A &= ~(1 << COM4A1) ;        // Clear Toggle OC4A pin on each timer      

			digitalWrite(MOTORSHIELD_IN1,LOW);      
			digitalWrite(MOTORSHIELD_IN2,LOW);
	   
			motor[MOTOR1].isActive = false;           //Stop
		//	return;
		}
		else
		{
			motor[MOTOR1].isActive = true;               //Start
			if(mxDir)
			{
				motor[MOTOR1].Dir =	FORWARD;
				digitalWrite(MOTORSHIELD_IN1,HIGH);
				digitalWrite(MOTORSHIELD_IN2,LOW);
			}
			else
			{
				motor[MOTOR1].Dir = BACKWARD;
				digitalWrite(MOTORSHIELD_IN1,LOW);
				digitalWrite(MOTORSHIELD_IN2,HIGH);                      
			}
			  
			TCCR4A &= ~(1<<WGM40); 
			TCCR4B &= ~((1 << CS42) | (1 << CS41) | (1 << CS40));
			TCCR4A |= (1 << COM4A1) ;        // Toggle OC4A pin on each timer     

			// PWM mode 14 (fast PWM, TOP=ICR1)
			TCCR4A |= (1 << WGM51);
			TCCR4B |= ((1 << WGM43) | (1 << WGM42));
		
			// Start timers (prescale=64)
			TCCR4B |= (0 << CS42) | (1 << CS41) | (1 << CS40);
		   
			motor[MOTOR1].Speed = ((int)mxSpeed * 0xFF) / 100;    
			OCR4A  = motor[MOTOR1].Speed;            
			
			// Set register values
			ICR4 = 0xFF;   
		}
   }
   
   if(motorID & MOTOR_ID_2)
   {
        DDRH |= (1 << 4);               // OC4B pin as outputs  
        PORTH &= ~(1 << 4);               // Clear the Pin 
		
        pinMode(MOTORSHIELD_IN3,OUTPUT);
        pinMode(MOTORSHIELD_IN4,OUTPUT);

	   if(mySpeed == 0)  // motor stop
       {
        PORTH &= ~(1 << 4);               // Clear the Pin 

        TCCR4A &=  ~(1 << COM4B1);        // Clear Toggle OC4B pin on each timer   

		digitalWrite(MOTORSHIELD_IN3,LOW);      
		digitalWrite(MOTORSHIELD_IN4,LOW);
	   
		motor[MOTOR2].isActive = false;           //Stop
		//return;
       }		
	   else
	   {
			if(myDir)
			{
				motor[MOTOR2].Dir =	FORWARD;		
				digitalWrite(MOTORSHIELD_IN3,HIGH);      
				digitalWrite(MOTORSHIELD_IN4,LOW);
			}
			else
			{
				motor[MOTOR2].Dir = BACKWARD;
				digitalWrite(MOTORSHIELD_IN3,LOW);      
				digitalWrite(MOTORSHIELD_IN4,HIGH);
			}

			TCCR4A &= ~(1<<WGM40); 
			TCCR4B &= ~((1 << CS42) | (1 << CS41) | (1 << CS40));
			TCCR4A |=  (1 << COM4B1);        // Toggle OC4B pin on each timer      
	   
			// PWM mode 14 (fast PWM, TOP=ICR1)
			TCCR4A |= (1 << WGM51);
			TCCR4B |= ((1 << WGM43) | (1 << WGM42));
		
			// Start timers (prescale=64)
			TCCR4B |= (0 << CS42) | (1 << CS41) | (1 << CS40);

			motor[MOTOR2].Speed = ((int)mySpeed * 0xFF) / 100;    
			OCR4B  = motor[MOTOR2].Speed;            
			
			// Set register values
			ICR4 = 0xFF;      
		}
   }
}

Motor::Motor()
{  
  
}

uint8_t Motor::driverGo(uint8_t motorID, int8_t mSpeed)
{
uint8_t mDir;


    if ((mSpeed > 100) || (mSpeed < -100))
	  return 1; 
	  
    if(mSpeed & 0x80)
	{
	  mDir = FORWARD;
	  mSpeed = -mSpeed;
	}
	else 
	  mDir = BACKWARD;
	  
	if(motorID & MOTOR_ID_1)
		motorDriverGo( MOTOR_ID_1, mDir, mSpeed, 0, 0, 0, 0);
	if(motorID & MOTOR_ID_2)
		motorDriverGo( MOTOR_ID_2, 0, 0, mDir, mSpeed, 0, 0);
    if(motorID & MOTOR_ID_3)
		motorDriverGo( MOTOR_ID_3, 0, 0, 0, 0 , mDir, mSpeed );
   
  return 0;
}



uint8_t Motor::driverGo(	uint8_t motorIDs, 
							int8_t mxSpeed,
							int8_t mySpeed,
							int8_t mzSpeed
						)
{	
 uint8_t mxDir,myDir,mzDir;
 
    if ((mxSpeed > 100) || (mxSpeed < -100))
	  return 1;
	  
	if ((mySpeed > 100) || (mySpeed < -100))
	  return 1;
	  
	if ((mzSpeed > 100) || (mzSpeed < -100))
	  return 1;
	  
	if(mxSpeed & 0x80)
	{
	  mxDir = FORWARD;
	  mxSpeed = -mxSpeed;
	}
	else 
	  mxDir = BACKWARD;
	  
	if(mySpeed & 0x80)
	{
	  myDir = FORWARD;
	  mySpeed = -mySpeed;
	}
	else 
	  myDir = BACKWARD; 
	  
	if(mzSpeed & 0x80)
	{
	  mzDir = FORWARD;
	  mzSpeed = -mzSpeed;
	}
	else 
	  mzDir = BACKWARD;


  motorDriverGo( 	motorIDs, 
					mxDir, mxSpeed ,
					myDir, mySpeed ,
					mzDir, mzSpeed 
				);
				
return 0;
}

void Motor::driverStop(uint8_t motorIDs)
{

    if(motorIDs & MOTOR_ID_1)
    {
      TIMSK2 &= ~((1<<OCIE2B) | (1<<TOIE2));
      TIFR2 = (1<<OCIE2B) | (1<<TOIE2);
      
      DDRH |= (1<<PH6);
      PORTH &= ~(1<<PH6);
      DDRJ |= (1<<PJ0);
      PORTJ &= ~(1<<PJ0);        
    }

    if(motorIDs & MOTOR_ID_2)
    {
        DDRH |= (1 << 3);               // OC4A pin as outputs 
        PORTH &= ~(1 << 3);               // // Clear the Pin 

        TCCR4A &= ~(1 << COM4A1) ;        // Clear Toggle OC4A pin on each timer      

        pinMode(MOTORSHIELD_IN1,OUTPUT);
        pinMode(MOTORSHIELD_IN2,OUTPUT);

        digitalWrite(MOTORSHIELD_IN1,LOW);      
        digitalWrite(MOTORSHIELD_IN2,LOW);
    }

    if(motorIDs & MOTOR_ID_3)
    {

        DDRH |= (1 << 4);               // OC4B pin as outputs  
        PORTH &= ~(1 << 4);               // Clear the Pin 

        TCCR4A &=  ~(1 << COM4B1);        // Clear Toggle OC4B pin on each timer   

        pinMode(MOTORSHIELD_IN3,OUTPUT);
        pinMode(MOTORSHIELD_IN4,OUTPUT);

        digitalWrite(MOTORSHIELD_IN3,LOW);      
        digitalWrite(MOTORSHIELD_IN4,LOW);
    }
}



