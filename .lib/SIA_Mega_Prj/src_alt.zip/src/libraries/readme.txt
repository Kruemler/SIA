Informationen zur Installation von Bibliotheken finden Sie unter: http://www.arduino.cc/en/Guide/Libraries
